﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using System.IO;
using System.Linq;

public class Controller : MonoBehaviour {
    public float viewRadius;
    [Range(0, 360)]
    public float viewAngle;
    public LayerMask obstacleMask;
    public LayerMask targetMask;
    [HideInInspector]

    public FieldOfView FOV;
    private List<string> targets = new List<string>();
    private List<string> hidden_targets = new List<string>();    
    private List<string> degreespoints = new List<string>();
    private float moveSpeed = 6;
    public GameObject character;
    Rigidbody rigidbody;
	Camera viewCamera;
	Vector3 velocity;
    StreamWriter writer;

    void Start ()
    {
		rigidbody = GetComponent<Rigidbody> ();
		viewCamera = Camera.main;
        string customPath = "./";
        writer = new StreamWriter(customPath+"targets.txt");
    }


    void Update () {
	Vector3 mousePos = viewCamera.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, viewCamera.transform.position.y));
	transform.LookAt (mousePos + Vector3.up * transform.position.y);
	velocity = new Vector3 (Input.GetAxisRaw ("Horizontal"), 0, Input.GetAxisRaw ("Vertical")).normalized * moveSpeed;
	}

	void FixedUpdate() {
		rigidbody.MovePosition (rigidbody.position + velocity * Time.fixedDeltaTime);
        int seen = FOV_seen(character.transform);
        int seen_360 = FOV_360(character.transform);
        int hidden = FOV_hidden(character.transform);
        Debug.Log("character position" + character.transform.position + " angle " + character.transform.eulerAngles.y + "|| number of targets seen 360° " + seen_360 + " ||number of targets seen in the FOV " + seen + " ||number of hidden targets " + hidden);
    }



    private int FOV_seen(Transform pos)
    {
        int seen = 0;
        //targets.Clear();
        Collider[] targetsInViewRadius = Physics.OverlapSphere(pos.position, viewRadius, targetMask);
        for (int i = 0; i < targetsInViewRadius.Length; i++)
        {
            Transform target = targetsInViewRadius[i].transform;
            Vector3 dirToTarget = (target.position - pos.transform.position).normalized;
            float dstToTarget = Vector3.Distance(pos.transform.position, target.position);
            if (Vector3.Angle(pos.transform.forward, dirToTarget) < viewAngle / 2)
            {
                if (!Physics.Raycast(pos.transform.position, dirToTarget, dstToTarget, obstacleMask) && pos.transform.position != target.transform.position)// if the target is visible in the field of view
                {
                    //targets_seen.Add(target.name);//use it if you what to know which targets can you see in the field of view
                    seen++;              
                }
            }
        }
        return seen;
    }

    private int FOV_hidden(Transform pos)
    {
        int hidden = 0;
        //hidden_targets.Clear();
        Collider[] targetsInViewRadius = Physics.OverlapSphere(pos.position, viewRadius, targetMask);
        for (int i = 0; i < targetsInViewRadius.Length; i++)
        {
            Transform target = targetsInViewRadius[i].transform;
            Vector3 dirToTarget = (target.position - pos.transform.position).normalized;
            float dstToTarget = Vector3.Distance(pos.transform.position, target.position);
            if (Vector3.Angle(pos.transform.forward, dirToTarget) < viewAngle / 2)
            {
                if (Physics.Raycast(pos.transform.position, dirToTarget, dstToTarget, obstacleMask) && pos.transform.position != target.transform.position)// if the target is visible in the field of view
                {
                    //hidden_targets.Add(target.name);//use it if you what to know which targets are hidden in the field of view
                    hidden++;                 
                }
            }
        }
        return hidden;
    }


    public int FOV_360(Transform targets)// use it if you want to know the name of the targets that are seen at 360°
    {
        int n = 0;
        //degreespoints.Clear();
        Collider[] targetsInViewRadius = Physics.OverlapSphere(targets.transform.position, viewRadius, targetMask);
        for (int i = 0; i < targetsInViewRadius.Length; i++)
        {
            Transform target = targetsInViewRadius[i].transform;
            Vector3 dirToTarget = (target.position - targets.position).normalized;
            float dstToTarget = Vector3.Distance(targets.transform.position, target.position);
            if (!Physics.Raycast(targets.transform.position, dirToTarget, dstToTarget, obstacleMask)  && target.transform.position != targets.transform.position)
            {
                //degreespoints.Add(target.name);
                n++;
            }
        }
        return n;
    }
     

}